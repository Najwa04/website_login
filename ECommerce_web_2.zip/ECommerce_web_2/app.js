const signUpPageLink = document.querySelector('#signup-page-link');
const loginPageLink = document.querySelector('#login-page-link');
const wrapper = document.querySelector('.wrapper');

const signUpButton = document.querySelector('#signup-button');
const signUpEmail = document.querySelector('#signup-email');
const signUpPassword = document.querySelector('#signup-password');
const signUpName = document.querySelector('#signup-name');

var firebaseConfig ={
    apiKey: "AIzaSyA9pyJge_NK9vHxjtniqe0yq8BjlATN_j8",
    authDomain: "login-signup-77758.firebaseapp.com",
    projectId: "login-signup-77758",
    storageBucket: "login-signup-77758.appspot.com",
    messagingSenderId: "360695814114",
    appId: "1:360695814114:web:0bf5385243e2d20f200bbb"
};

  firebase.initializeApp(firebaseConfig);
  const auth = firebase.auth();

signUpPageLink.addEventListener('click',function(){
    wrapper.style.top='-100%';

})

loginPageLink.addEventListener('click',function(){
    wrapper.style.top = '0%';
})

signUpButton.addEventListener('click', function(){
    auth.createUserWithEmailAndPassword(signUpEmail.value , signUpPassword.value)
    .then((userCredential)=>{
        var user = userCredential.user;
        var currentUser = auth.currentUser;
        currentUser.updateProfile({
            displayName:signUpName.value,
        })
        // console.log(user);
    })
    .catch((e)=>{
        console.log(e.message);
    })
})

